

class Environment(object):
    TEST = 'https://apitest.authorize.net/xml/v1/request.api'
    PRODUCTION = 'https://api.authorize.net/xml/v1/request.api'
